import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';

import '../main.dart';

const String _loginUrl = 'http://192.168.18.24:8000/api/auth/login'; 

class LoginPage extends StatefulWidget {
  @override
  _LoginPageState createState() => _LoginPageState();
}

class _LoginPageState extends State<LoginPage> {
  bool _isLoading = false;

  final TextEditingController emailController = TextEditingController();
  final TextEditingController passwordController = TextEditingController();

  @override
  void dispose() {
    emailController.dispose();
    passwordController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    SystemChrome.setSystemUIOverlayStyle(SystemUiOverlayStyle.light.copyWith(
      statusBarColor: Colors.transparent,
    ));

    return Scaffold(
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [Colors.blue, Colors.teal],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: _isLoading
            ? const Center(child: CircularProgressIndicator())
            : ListView(
                children: <Widget>[
                  headerSection(),
                  textSection(),
                  buttonSection(),
                ],
              ),
      ),
    );
  }

  // ------------------------------------------------------------------
  // 🔑 FUNCIÓN DE LOGIN ADAPTADA 🔑
  // ------------------------------------------------------------------
  Future<void> signIn(String email, String password) async {
    // 1. Iniciar carga
    setState(() {
      _isLoading = true;
    });

    final prefs = await SharedPreferences.getInstance();

    // 2. Preparar datos y URL
    Map<String, String> data = {
      'email': email,
      'password': password,
    };
    final url = Uri.parse(_loginUrl);

    try {
      // 3. Realizar petición POST con cabeceras y cuerpo JSON
      var response = await http.post(
        url,
        headers: <String, String>{
          'Content-Type': 'application/json; charset=UTF-8',
        },
        body: jsonEncode(data), // Codificar el Map a JSON String
      );

      // 4. Manejar respuesta
      if (response.statusCode == 200) {
        // Respuesta exitosa
        var jsonResponse = json.decode(response.body);
        print('Response status: ${response.statusCode}');
        print('Response body: ${response.body}');
        
        // ** Extraer el Token de la Cookie (si el backend lo envía así) **
        String? rawCookie = response.headers['set-cookie'];
        String? token;
        
        if (rawCookie != null) {
          // Buscar el valor de la cookie 'token'
          final tokenMatch = RegExp(r'token=([^;]+)').firstMatch(rawCookie);
          token = tokenMatch?.group(1);
        }

        if (token != null && token.isNotEmpty) {
          // Guardar el token extraído para futuras peticiones autenticadas
          prefs.setString("token", token); // Cambié el nombre para mayor claridad
          
          // Navegar a la página principal
          Navigator.of(context).pushAndRemoveUntil(
            MaterialPageRoute(builder: (_) => MainPage()),
            (Route<dynamic> route) => false,
          );
        } else if (jsonResponse != null && jsonResponse['token'] != null) {
            // Caso alternativo: Si el backend envía el token directamente en el body (no en cookie)
             prefs.setString("token", jsonResponse['token']);
             Navigator.of(context).pushAndRemoveUntil(
                MaterialPageRoute(builder: (_) => MainPage()),
                (Route<dynamic> route) => false,
             );
        } else {
             // Falla si no se encuentra el token
             ScaffoldMessenger.of(context).showSnackBar(
               const SnackBar(content: Text('Login successful, but token missing.')),
             );
        }

      } else if (response.statusCode == 401) {
        // Error de credenciales (Unauthorized)
        var jsonResponse = json.decode(response.body);
        String errorMessage = jsonResponse['message'] ?? 'Invalid email or password.';
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(errorMessage)),
        );
      } else {
        // Otros errores del servidor
        print('Error status ${response.statusCode}: ${response.body}');
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Login failed. Server error.')),
        );
      }
    } catch (e) {
      // Error de conexión (ej: servidor apagado, IP incorrecta)
      print('Exception: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Error connecting to server. Check network.')),
      );
    } finally {
      // 5. Finalizar carga
      setState(() {
        _isLoading = false;
      });
    }
  }
  // ------------------------------------------------------------------

  Container buttonSection() {
    bool isButtonEnabled =
        emailController.text.isNotEmpty && passwordController.text.isNotEmpty;

    return Container(
      width: MediaQuery.of(context).size.width,
      height: 50.0,
      padding: const EdgeInsets.symmetric(horizontal: 15.0),
      margin: const EdgeInsets.only(top: 15.0),
      child: ElevatedButton(
        onPressed: isButtonEnabled
            ? () => signIn(emailController.text, passwordController.text)
            : null,
        style: ElevatedButton.styleFrom(
          backgroundColor: Colors.purple,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(5.0)),
        ),
        child: const Text(
          "Sign In",
          style: TextStyle(color: Colors.white70),
        ),
      ),
    );
  }

  Container textSection() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 15.0, vertical: 20.0),
      child: Column(
        children: <Widget>[
          TextFormField(
            controller: emailController,
            cursorColor: Colors.white,
            style: const TextStyle(color: Colors.white70),
            decoration: const InputDecoration(
              icon: Icon(Icons.email, color: Colors.white70),
              hintText: "Email",
              hintStyle: TextStyle(color: Colors.white70),
              border: UnderlineInputBorder(
                borderSide: BorderSide(color: Colors.white70),
              ),
            ),
          ),
          const SizedBox(height: 30.0),
          TextFormField(
            controller: passwordController,
            cursorColor: Colors.white,
            obscureText: true,
            style: const TextStyle(color: Colors.white70),
            decoration: const InputDecoration(
              icon: Icon(Icons.lock, color: Colors.white70),
              hintText: "Password",
              hintStyle: TextStyle(color: Colors.white70),
              border: UnderlineInputBorder(
                borderSide: BorderSide(color: Colors.white70),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Container headerSection() {
    return Container(
      margin: const EdgeInsets.only(top: 50.0),
      padding: const EdgeInsets.symmetric(horizontal: 20.0, vertical: 30.0),
      child: const Text(
        "Pizzeria Don Mario",
        style: TextStyle(
          color: Colors.white70,
          fontSize: 40.0,
          fontWeight: FontWeight.bold,
        ),
      ),
    );
  }
}

