import 'package:flutter/material.dart';
// Asegúrate de usar la ruta correcta a tu DataBaseHelper
import '../controllers/databasehelpers.dart'; 

// Renombrado para reflejar que lista Pedidos
class ListPedidos extends StatefulWidget {
  const ListPedidos({super.key}); 

  @override
  _ListPedidosState createState() => _ListPedidosState();
}

class _ListPedidosState extends State<ListPedidos> {
  // Usamos el Helper para la lógica de la API
  final DataBaseHelper _dbHelper = DataBaseHelper();
  late Future<List<dynamic>> _pedidosFuture;

  @override
  void initState() {
    super.initState();
    // 1. Llamada a la función del Helper que maneja el token
    _pedidosFuture = _dbHelper.obtenerPedidos();
  }
  
  // Función para recargar la lista
  Future<void> _refreshPedidos() async {
    setState(() {
      _pedidosFuture = _dbHelper.obtenerPedidos();
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("Lista de Pedidos 🛍️"), // Título corregido
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _refreshPedidos,
          ),
        ],
      ),
      body: FutureBuilder<List<dynamic>>(
        future: _pedidosFuture,
        builder: (context, snapshot) {
          if (snapshot.connectionState == ConnectionState.waiting) {
            return const Center(child: CircularProgressIndicator());
          }
          
          if (snapshot.hasError) {
            // Mostrar un error más amigable para el usuario
            print('Error en FutureBuilder: ${snapshot.error}');
            return Center(child: Text('Error al cargar pedidos: ${snapshot.error.toString()}'));
          }

          if (!snapshot.hasData || snapshot.data!.isEmpty) {
            return const Center(child: Text('No hay pedidos disponibles.'));
          }
          
          // 2. Usar el widget ItemList con los datos de Pedidos
          return RefreshIndicator(
            onRefresh: _refreshPedidos,
            child: PedidoItemList(list: snapshot.data!),
          );
        },
      ),
    );
  }
}

// Renombrado para reflejar que lista Pedidos
class PedidoItemList extends StatelessWidget {
  final List<dynamic> list;

  const PedidoItemList({super.key, required this.list}); 

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      itemCount: list.length,
      itemBuilder: (context, i) {
        final pedido = list[i];
        
        // 3. Extracción segura de datos anidados (basado en tu API de Express/Sequelize)
        // Ejemplo: cliente.nombre y estadoPedido.nombre
        final clienteNombre = pedido['cliente']?['nombre'] ?? 'Cliente Desconocido';
        final estado = pedido['estadoPedido']?['nombre'] ?? 'Estado N/A';
        final total = pedido['total']?.toStringAsFixed(2) ?? '0.00';

        return Container(
          padding: const EdgeInsets.all(10.0),
          child: GestureDetector(
            // Nota: Aquí necesitarías crear la clase 'Detail'
            onTap: () => {
            },
            child: Card(
              elevation: 4,
              child: ListTile(
                leading: const Icon(Icons.receipt_long, color: Colors.deepOrange),
                // Mostrar ID y total
                title: Text(
                  'Pedido #${pedido['id']} - Total: \$$total',
                  style: const TextStyle(
                    fontSize: 18.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                subtitle: Text('Cliente: $clienteNombre\nEstado: $estado'),
                trailing: const Icon(Icons.arrow_forward_ios),
              ),
            ),
          ),
        );
      },
    );
  }
}

  