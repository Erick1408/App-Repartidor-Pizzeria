import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';

class DataBaseHelper {
  // Asegúrate de usar la IP y puerto correctos para tu servidor
  // He mantenido la IP que usaste para el endpoint de pedidos.
  final String _serverBaseUrl = 'http://192.168.18.24:8000/api';
  
  var status;
  var token;

  // --- 1. OBTENER Y LISTAR TODOS LOS PEDIDOS (GET /api/pedido) ---
  // He corregido la URL para usar el endpoint base y la he hecho asíncrona.
  Future<List<dynamic>> obtenerPedidos() async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token') ?? ''; // 'value' renombrado a 'token'

    final Uri myUrl = Uri.parse('$_serverBaseUrl/pedido');
    
    try {
      final response = await http.get(
        myUrl,
        headers: {
          'Accept': 'application/json',
          // Incluir el token de autorización
          'Authorization': 'Bearer $token', 
        },
      );

      if (response.statusCode == 200) {
        // Retorna la lista de pedidos decodificada
        return json.decode(response.body);
      } else if (response.statusCode == 401) {
        print('Error 401: No autorizado. Token inválido o expirado.');
        return [];
      } else {
        print('Error al obtener pedidos. Código: ${response.statusCode}');
        print('Respuesta del servidor: ${response.body}');
        return [];
      }
    } catch (e) {
      print('Error de conexión o inesperado: $e');
      return [];
    }
  }

  // --- 2. ACTUALIZAR ESTADO DE UN PEDIDO (PUT /api/pedido/{id}/estado) ---
  // Nueva función solicitada para cambiar el estado.
  Future<bool> actualizarEstadoPedido(int pedidoId, int nuevoEstadoId) async {
    final prefs = await SharedPreferences.getInstance();
    final token = prefs.getString('token') ?? '';
    
    final Uri myUrl = Uri.parse('$_serverBaseUrl/pedido/$pedidoId/estado');

    try {
      final response = await http.put(
        myUrl,
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer $token',
        },
        // El cuerpo debe ser un mapa JSON con el nuevo ID de estado
        body: json.encode({
          'id_estado': nuevoEstadoId,
        }),
      );

      if (response.statusCode == 200) {
        print('Estado del pedido $pedidoId actualizado a $nuevoEstadoId con éxito.');
        return true;
      } else {
        print('Fallo al actualizar estado. Código: ${response.statusCode}. Respuesta: ${response.body}');
        return false;
      }
    } catch (e) {
      print('Error de conexión al actualizar estado: $e');
      return false;
    }
  }

  // FUNCIÓN GUARDAR TOKEN
  Future<void> _save(String token) async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString('token', token);
  }

  // FUNCIÓN LEER TOKEN
  Future<void> read() async {
    final prefs = await SharedPreferences.getInstance();
    final value = prefs.getString('token') ?? '';
    print('read : $value');
  }
}


