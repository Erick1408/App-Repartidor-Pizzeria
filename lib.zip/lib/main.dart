
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

// Importaciones
import '../view/listProducts.dart'; 
import '../view/loginPage.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: "PIZZERIA DON MARIO",
      debugShowCheckedModeBanner: false,
      home: const MainPage(),
      theme: ThemeData(
        // Color más de pizza
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.deepOrange), 
        useMaterial3: true,
      ),
    );
  }
}

class MainPage extends StatefulWidget {
  const MainPage({super.key});

  @override
  State<MainPage> createState() => _MainPageState();
}

class _MainPageState extends State<MainPage> {
  late SharedPreferences sharedPreferences;

  @override
  void initState() {
    super.initState();
    checkLoginStatus();
  }

  Future<void> checkLoginStatus() async {
    sharedPreferences = await SharedPreferences.getInstance();
    if (!mounted) return;
    // Lógica de verificación de token NO MODIFICADA
    if (sharedPreferences.getString("token") == null) {
      Navigator.of(context).pushAndRemoveUntil(
        MaterialPageRoute(builder: (_) => LoginPage()),
        (route) => false,
      );
    }
  }

  void logout() {
    sharedPreferences.clear();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => LoginPage()),
      (route) => false,
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        // Usar color del tema
        backgroundColor: Theme.of(context).colorScheme.primary, 
        title: const Text(
          "Pizzeria Don Mario",
          style: TextStyle(color: Colors.white),
        ),
        actions: [
          TextButton(
            onPressed: logout,
            child: const Text(
              "Cerrar Sesión",
              style: TextStyle(color: Colors.white),
            ),
          ),
        ],
      ),
      body: const Center(child: Text("Bienvenido al Panel de Pedidos")),
      
      drawer: Drawer(
        child: ListView(
          children: [
            UserAccountsDrawerHeader(
              accountName: const Text('Usuario Autenticado'), 
              accountEmail: const Text('rol@pizzeria.com'),
              decoration: BoxDecoration(color: Theme.of(context).primaryColor),
            ),
            
            // --- NAVEGACIÓN A LISTADO DE PEDIDOS ---
            ListTile(
              title: const Text("Lista de Pedidos"),
              // Icono más representativo
              trailing: const Icon(Icons.receipt_long), 
              onTap: () {
                // Usamos tu importación ListProducts
                Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const ListPedidos()), 
                );
                // Cierra el drawer después de navegar
                Navigator.pop(context); 
              },
            ),
            
            const Divider(),
            
            // --- OPCIÓN DE REGISTRO (Mantenida) ---
            ListTile(
              title: const Text("Register"),
              trailing: const Icon(Icons.person_add),
              onTap: () {
                // Solo cierra el drawer si no hay navegación
                Navigator.pop(context); 
              },
            ),
          ],
        ),
      ),
    );
  }
}
